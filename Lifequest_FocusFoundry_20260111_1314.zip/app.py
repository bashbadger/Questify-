from flask import Flask, request, jsonify, render_template, session, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import hashlib

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ghostcart.db'
app.config['SECRET_KEY'] = 'ghost-secret-123'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True)
    password = db.Column(db.String(128))

class SimulatedItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    price_cents = db.Column(db.Integer)
    image_url = db.Column(db.String(200))

@app.route('/')
def splash(): return render_template('index.html')

@app.route('/shop')
def shop_page(): return render_template('shop.html')

@app.route('/api/items')
def get_items():
    # Mocking data for the zip demo
    items = [
        {'id': 1, 'name': 'Luxury Watch', 'price': 250.00, 'img': 'https://via.placeholder.com/150'},
        {'id': 2, 'name': 'Designer Sneakers', 'price': 120.00, 'img': 'https://via.placeholder.com/150'},
        {'id': 3, 'name': 'Smart Headphones', 'price': 350.00, 'img': 'https://via.placeholder.com/150'}
    ]
    return jsonify(items)

@app.route('/api/save', methods=['POST'])
def save_money():
    data = request.json
    return jsonify({
        "status": "success", 
        "receipt": {"item": data['name'], "purchased": "None", "saved": data['price']}
    })

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)

@app.route('/settings')
def settings_page(): return render_template('settings.html')
